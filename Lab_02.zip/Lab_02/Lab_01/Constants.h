#pragma once

static const int WINDOW_X = 1600;
static const int WINDOW_Y = 1000

;